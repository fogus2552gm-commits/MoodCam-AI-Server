MOODCAM AI SERVER
==================
This folder contains the Flask + DeepFace backend.

Deploy this folder to a service that can run Python/Flask and expose HTTPS.
After deployment, copy the HTTPS base URL into:
../js/config.js

Example:
window.MOODCAM_API_URL = "https://your-ai-server.example.com";

Netlify does NOT run this Python backend.
